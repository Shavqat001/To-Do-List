'use strict';

function thanosEffect(el) {
  const list = el.querySelectorAll('[data-type="post"]');
  console.log(list);
  Array.from(list)
    .filter((elem, i) => i % 2 === 0)
    .forEach((post) => {
      post.style.visibility = 'hidden';
    });
}

const postsEl = document.querySelector('[data-id="posts"]');
thanosEffect(postsEl);