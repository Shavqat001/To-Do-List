function calculateCommission(amount, total) {

    const percent = 0.7;
    const minCommission = 0.35;
    const totalSum = 5000;

    const commission = ((amount + total - totalSum) * percent) / 100;
    if (amount+total <= totalSum) {
        return 0;
    } else {
        if (commission < minCommission) {
            return minCommission;
        }
        return commission;
    }
}

const amount = 1000;
const total = 0;

const result = calculateCommission(amount, total);
console.log(result);