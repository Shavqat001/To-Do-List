import React from 'react'
import './Post.css';
import Tags from '../Tags/Tags';

function Post({ post, onLike, onDelete, onHide, onShow, onEdit }) {
    const { author } = post;
    const { photo } = post;

    const handleClick = () => {
        onLike(post.id);
    };
    const handleDelete = () => {
        onDelete(post.id);
    }
    const handleHide = () => {
        onHide(post.id);
    }
    const handleShow = () => {
        onShow(post.id)
    }

    const handleEdit=()=>{
        onEdit(post.id)
    }

    if (post.hidden) {
        return (
            <article>
                <header>
                    <img src={author.avatar} className='Post-avatar' width="50" height="50" alt={author.name} />
                    <h5>{author.name}</h5>
                    <button onClick={handleShow}>показать</button>
                </header>
            </article>
        )
    };
    return (
        <article>
            <header>
                <img src={author.avatar} className='Post-avatar' width="50" height="50" alt={author.name} />
                <h5>{author.name}</h5>
                <button onClick={handleDelete}>удалить</button>
                <button onClick={handleHide}>скрыть</button>
                <button onClick={handleEdit}>изменть</button>
                <div>{post.created}</div>
                {post.hit && <span>HIT</span>}
            </header>
            <div>
                <div className='Post-content'>{post.content}</div>
                {post.photo && <img className='Post-photo' src={photo.url} alt={photo.alt} />}
            </div>
            <footer>
                <span className='Post-likes' onClick={handleClick}>
                    <img alt="likes" width="20" height="20" src={
                        post.likedByMe
                            ?
                            'https://alif-skills.pro/media/liked.svg'
                            :
                            'https://alif-skills.pro/media/unliked.svg'} />
                    <span className="Post-likes-count">{post.likes}</span>
                    {post.tags && <Tags tags={post.tags} />}
                </span>
            </footer>
        </article>
    );
}

export default Post