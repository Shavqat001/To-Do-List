const fs = require('node:os');
const userInfo = fs.userInfo();
console.log(userInfo.username);