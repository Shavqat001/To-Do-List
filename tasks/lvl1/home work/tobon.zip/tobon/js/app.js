'use strict';

function bindPartnerToEl(partner, el) {
    const linkEl = el.querySelector('[data-id="partner-link"]');
    const logo = el.querySelector('[data-id="logo"]');
    const title = el.querySelector('[data-id="title"]');
    const period = el.querySelector('[data-id="period"]');
    const category = el.querySelector('[data-id="category"]');

    linkEl.setAttribute('href', partner.url);
    logo.setAttribute('src', partner.logoUrl);
    logo.setAttribute('alt', partner.id);
    title.textContent = partner.title;
    period.textContent = partner.period;
    category.textContent = partner.category;
}

const partner = {
    id: 'tobon',
    url: 'https://salom.alif.tj/partners/tobon',
    logoUrl: 'https://alif-skills.pro/media/tobon.svg',
    title: 'Тобон',
    category: 'Отопление',
    period: 12,
};

const partnerEl = document.querySelector('[data-block="partner"]');
bindPartnerToEl(partner, partnerEl);