'use strict';

function extractOwnerId(postId) {
    const selector = document.querySelector(`[data-id="${postId}"]`);
    const ownerId = selector.getAttribute('data-ownerid');
    return ownerId;
}
extractOwnerId(1);