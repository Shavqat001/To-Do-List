const input = 10000;
const storePercent = 50;

const cashback = input * storePercent / 1000;

console.log(cashback);