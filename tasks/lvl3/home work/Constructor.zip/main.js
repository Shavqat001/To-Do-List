'use strict';

function Post(id, title, content) {
    this.id = id;
    this.title = title;
    this.content = content;
}

Post.prototype.preview = function () {
    const arrOfText = this.content.split(' ');
    for (let i = 0; i < arrOfText.length; i++) {
        if (arrOfText[i].endsWith('.')) {
            return arrOfText.slice(0, i + 1).join(' ');
        }
    }
    return arrOfText.join(' ');
};

const post = new Post(1, 'hacker', 'I am The best hacker Man');
console.log(post.preview()); // выводит "I am The."