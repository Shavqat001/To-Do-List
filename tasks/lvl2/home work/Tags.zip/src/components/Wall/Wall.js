import React from 'react'
import Post from '../Post/Post'

function Wall(props) {
    console.log(props);
    const posts = [
        {
            id: 2,
            author: {
                id: 1,
                avatar: 'https://alif-skills.pro/media/logo_alif.svg',
                name: 'Alif Skills',
            },
            content: 'Ну как, вы справились с домашкой?',
            photo: null,
            hit: true,
            likes: 222,
            likedByMe: true,
            created: 1603774800,
        },
        {
            id: 1,
            author: {
                id: 1,
                avatar: 'https://alif-skills.pro/media/logo_alif.svg',
                name: 'Alif Skills',
            },
            content: null,
            photo: {
                url: "https://alif-skills.pro/media/meme.jpg",
                alt: 'Мем про дедлайн',
            },
            hit: true,
            likes: 10,
            likedByMe: true,
            tags: ['deadline', 'homeworks'],
            created: 1603501200,
        },
    ];

    return (
        <div>
            {posts.map(o => <Post key={o.id} post={o} />)}
        </div>
    );
}

export default Wall