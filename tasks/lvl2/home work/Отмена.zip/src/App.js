import './App.css';
import Message from './components/Message/Message';
import Wall from './components/Wall/Wall';

function App() {
  return (
    <div className="App">
      <Wall />
      <Message text='Первое сообщение' />
      <Message text='Второе сообщение' />
      <Message text='Третье сообщение' />
    </div>
  );
}

export default App;
