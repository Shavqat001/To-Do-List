import React, { useContext } from 'react';
import './Post.css';
import Tags from '../Tags/Tags';
 import {edit, hide, like, remove, show} from '../../store/actions'
// import { useDispatch } from 'react-redux';
import PostsContext from '../../contexts/PostsContext';

function Post({post}) {

  const {dispatch} = useContext(PostsContext);
  
  // const dispatch = useDispatch();
  const handleLike = () => {
    dispatch(like(post.id));
    //dispatch({type: 'POST_LIKE', payload: {id: post.id}})
  }

  const handleRemove = () => {
    dispatch(remove(post.id));
    // dispatch({type: 'POST_REMOVE', payload: {id: post.id}})
  }

  const handleHide = () => {
    dispatch(hide(post.id));
    // dispatch({type: 'POST_HIDE', payload: {id: post.id}})
  }

  const handleShow = () => {
    dispatch(show(post.id));
    // dispatch({type: 'POST_SHOW', payload: {id: post.id}})
  }

  const handleEdit = () => {
    dispatch(edit(post.id));
    // dispatch({type: 'POST_EDIT', payload: {id: post.id}})
  }


  if (post.hidden) {
    return (
      <article>
        <header>
          <img src={post.author.avatar} className="Post-avatar" width="50" height="50" alt={post.author.name} />
          <h5>{post.author.name}</h5>
          <button onClick={handleShow}>показать</button>
        </header>
      </article>
    )
  }

  if (post !== undefined) {
    return (
      <article>
        <header>
          <img src={post.author.avatar} className="Post-avatar" width="50" height="50" alt={post.author.name} />
          <h5>{post.author.name}</h5>
          <button onClick={handleRemove}>удалить</button>
          <button onClick={handleHide}>скрыть</button>
          <button onClick={handleEdit}>изменить</button>
          <div>{post.created}</div>
          {post.hit && <span>HIT</span>}
        </header>
        <div>
          <div className="Post-content">{post.content}</div>
          {post.photo && <img src={post.photo.url} alt={post.photo.alt} className="Post-photo" />}
        </div>
        <footer>
          <span className="Post-likes" onClick={handleLike} >
            <img src={post.likedByMe ? "https://alif-skills.pro/media/liked.svg":"https://alif-skills.pro/media/unliked.svg"} 
            alt="likes" 
            width="20" 
            height="20"
            />
            <span className="Post-likes-count" >{post.likes}</span>
            {post.tags && <Tags tags={post.tags} />}
          </span>
        </footer>
      </article>
    )
  }
  }
 


export default Post