INSERT INTO banners (
    title, 
    content, 
    button, 
    link, 
    image
    )
VALUES (
    'Осуществите свои мечты',
    'Вкладывайте депозит в Алифе и получайте больше половины от дохода',
    'Вкладывать',
    'https://alif.tj/deposit#CountYourIncome',
    'granat.svg'
    );