'use strict';

const photos = [
    { id: 1, src: 'img/1.jpg', alt: 'first', },
    { id: 3, src: 'img/3.jpg', alt: 'third', },
    { id: 2, src: 'img/2.jpg', alt: 'second', },
    { id: 4, src: 'img/4.jpg', alt: 'fourth', },
];

function bindPhotoToViewer(photo, el) {
    const btnLeft = el.querySelector('[data-action="prev"]');
    const btnRight = el.querySelector('[data-action="next"]');
    const logo = el.querySelector('[data-id="photo"]');

    let counter = 0;

    window.onload = () => {
        logo.src = photo[0].src;
        logo.alt = photo[0].alt;
        btnLeft.disabled = true;
    };

    btnRight.onclick = () => {
        photo[counter++];
        if (counter >= photo.length - 1) {
            btnRight.disabled = true;
        }
        btnLeft.disabled = false;
        logo.src = photo[counter].src;
        logo.alt = photo[counter].alt;
    };

    btnLeft.onclick = () => {
        photo[counter--];
        if (counter <= 0) {
            btnLeft.disabled = true;
        }
        btnRight.disabled = false;
        logo.src = photo[counter].src;
        logo.alt = photo[counter].alt;
    };
}
bindPhotoToViewer(photos, document);