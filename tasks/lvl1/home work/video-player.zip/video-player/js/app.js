'use strict';

const videoEl = document.querySelector('[data-id="video"]');

const playBtn = document.querySelector('[data-action="play"]');
const pauseBtn = document.querySelector('[data-action="pause"]');
const volumePlus = document.querySelector('[data-action="volume-plus"]');
const volumeMinus = document.querySelector('[data-action="volume-minus"]');

playBtn.onclick = () => {
    videoEl.play();
};

pauseBtn.onclick = () => {
    videoEl.pause();
};

volumePlus.onclick = () => {
    if (videoEl.volume < 1) {
        videoEl.volume += 0.1;
    }
};

volumeMinus.onclick = () => {
    if (videoEl.volume > 0) {
        videoEl.volume -= 0.1;
    }
};