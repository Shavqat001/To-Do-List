SELECT id, title, content, button, link, image, created
FROM banners
WHERE id = 2;