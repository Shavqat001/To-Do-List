DELETE FROM banners
WHERE id = 5;