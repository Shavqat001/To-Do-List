const sum = 1000;
const prct = 50;
function calculateCashback(amount, percent) {
    const cashback = amount * percent / 100;
    return cashback;
}
const result = calculateCashback(sum, prct);
console.log(result);