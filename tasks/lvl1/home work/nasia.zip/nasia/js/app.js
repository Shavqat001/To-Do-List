'use strict';

const buttonNasia = document.querySelector('[data-tab="nasia"]');
const buttonAlifmobi = document.querySelector('[data-tab="alifmobi"]');

const nasiaTabPane = document.querySelector('[data-tabpane="nasia"]');
const alifmobiTabPane = document.querySelector('[data-tabpane="alifmobi"]');

alifmobiTabPane.style.display = 'none';

buttonNasia.onclick = () => {
    buttonNasia.disabled = true;
    buttonAlifmobi.disabled = false;
    nasiaTabPane.style.display = 'block';
    alifmobiTabPane.style.display = 'none';
};

buttonAlifmobi.onclick = () => {
    buttonAlifmobi.disabled = true;
    buttonNasia.disabled = false;
    nasiaTabPane.style.display = 'none';
    alifmobiTabPane.style.display = 'block';
};