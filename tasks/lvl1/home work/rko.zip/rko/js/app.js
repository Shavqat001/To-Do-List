const percent = 0.2;

const dollar = 1000;
const somoni = 11.40;
const minComisson = 250;
const maxComisson = 450;

function calculateCommission(amount, rate) {
    const comission = (amount * rate) / 100 * percent;
    if (comission < minComisson) {
        return minComisson; 
    } else if (comission > maxComisson) {
        return maxComisson;
    } 
    return comission;
}

const result = calculateCommission(dollar, somoni);
console.log(result);