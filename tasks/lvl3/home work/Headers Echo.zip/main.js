'use strict';

const { createServer } = require('node:http');

const server = createServer((req, res) => {
    res.setHeader('Content-Type', 'text/plain');
    const headers = req.headers;
    let responseText = '';
    for (const key in headers) {
        responseText += `${key}: ${headers[key]}\n`;
    }
    res.end(responseText);
});

const port = 9999;
server.listen(port);