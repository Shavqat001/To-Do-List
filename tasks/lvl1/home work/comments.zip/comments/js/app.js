'use strict';

let nextId = 1;
const formEl = document.createElement('form');

const comments = [];

const rootEl = document.querySelector('#root');

const btnEl = document.createElement('button');
btnEl.dataset.action = 'add';
btnEl.textContent = 'Добавить';

formEl.dataset.id = 'comment-form';

const textAreaEl = document.createElement('textarea');
textAreaEl.dataset.input = 'comment';

formEl.append(textAreaEl);

const list = document.createElement('ul');
list.dataset.id = 'comment-list';

formEl.append(btnEl);
rootEl.append(formEl);
rootEl.append(list);

const message = document.createElement('div');
message.dataset.id = 'message';
formEl.append(message);

formEl.onsubmit = (evt) => {
    evt.preventDefault();

    if (textAreaEl.value) {
        comments.push(
            {
                id: nextId,
                text: textAreaEl.value.trim(),
            },);
        
        const item = document.createElement('li');

        item.textContent = textAreaEl.value.trim();
        item.dataset.commentId = nextId++;
        list.append(item);
        message.textContent = '';

        textAreaEl.focus();
        textAreaEl.value.trim();
        formEl.reset();

    } else {
        textAreaEl.focus();
        message.textContent = 'Значение поля не может быть пустым';
    }
};