'use strict';

const posts = [
    {
        id: 3,
        type: 'text',
        content: 'Final Week!',
    },
    {
        id: 2,
        type: 'image',
        content: 'img/logo_js.svg',
    },
    {
        id: 1,
        type: 'video',
        content: 'video/video.mp4',
    },
];

const rootEl = document.getElementById('root');

function makePostEl(post) {
    const div = document.createElement('div');
    div.setAttribute('data-type', post.type);
    div.setAttribute('data-id', post.id);

    if (post.type === 'text') {
        const el = document.createElement('div');
        el.textContent = post.content;
        div.append(el);
    }
    if (post.type === 'image') {
        const img = document.createElement('img');
        img.setAttribute('src', post.content);
        div.append(img);
    }
    if (post.type === 'video') {
        const video = document.createElement('video');
        video.setAttribute('src', post.content);
        div.append(video);
    }
    return div;
}

function makeWall(el, items) {
    items.map(makePostEl).forEach(element => el.append(element));
}
makeWall(rootEl, posts);

