import React, { useEffect, useRef, useState } from 'react'

const empty = {
    id: 0,
    author: {
        id: 1,
        avatar: 'https://alif-skills.pro/media/logo_alif.svg',
        name: 'Alif Skills',
    },
    content: '',
    photo: null,
    hit: false,
    likes: 0,
    likedByMe: false,
    hidden: false,
    tags: null,
    created: 0,
}
function PostForm({ edited = empty, onSave, onCancel }) {
    const [post, setPost] = useState(edited);
    const firstFocusEl = useRef(null);
    useEffect(() => {
        setPost(edited);
    }, [edited]);

    const handleSubmit = (evt) => {
        evt.preventDefault();
        const parsed = post.tags?.map(p => p.replace('#', '')).filter(f => f.trim() !== '') || [];
        const tags = parsed.length !== 0 ? parsed : null;
        onSave({
            ...post,
            id: post.id || Date.now(),
            created: post.created || Date.now(),
            tags,
            photo: post.photo?.url ? { alt: '', ...post.photo } : null
        });
        setPost(empty);
        firstFocusEl.current.focus();
    };

    const handleCancel = (evt) => {
        evt.preventDefault();
        setPost(empty);
        onCancel();
    };

    const handleChange = (evt) => {
        const { name, value } = evt.target;
        if (name === 'tags') {
            const parsed = value.split(' ');
            setPost((prevState) => ({ ...prevState, [name]: parsed }));
            return;
        }
        if (name === 'photo') {
            setPost((prevState) => ({
                ...prevState,
                photo: { ...prevState.photo, url: value }
            }));
            return;
        }
        if (name === 'alt') {
            setPost((prevState) => ({
                ...prevState,
                photo: { ...prevState.photo, alt: value }
            }));
            return;
        }
        setPost((prevState) => ({ ...prevState, [name]: value }));
    };
    return (
        <form onSubmit={handleSubmit}>
            <textarea
                ref={firstFocusEl}
                name='content'
                placeholder='content'
                value={post.content || ''}
                onChange={handleChange} />
            <input
                name='tags'
                placeholder='tags'
                value={post.tags?.join(' ') || ''}
                onChange={handleChange}
            />
            <input
                name='photo'
                placeholder='photo'
                value={post.photo?.url || ''}
                onChange={handleChange}
            />
            <input
                name='alt'
                placeholder='alt'
                value={post.photo?.alt || ''}
                onChange={handleChange}
            />
            {edited.id && (
                <button type="button" onClick={handleCancel}>
                    Отменить
                </button>
            )}
            <button>Ok</button>
        </form>
    )
}

export default PostForm