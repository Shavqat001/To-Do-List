import React,{useMemo, useReducer} from 'react'
import PostsContext from './PostsContext'
import {reducer, initialState} from '../store/reducers'


export default function PostsProvider(props) {
  // const [posts, setPosts] = useState([]);
  // const [edited, setEdited] = useState(empty);

  // const like = (id) => {
  //   setPosts((prevState) => prevState.map(post => {
  //     if (post.id !== id) {
  //       return post
  //     }

  //     const likedByMe = !post.likedByMe;
  //     const likes = likedByMe ? post.likes + 1 : post.likes - 1
  //     return {...post, likedByMe, likes}
  // }))
  // }

  // const remove = (id) => { 
  //   setPosts((prevState) => prevState.filter(post => post.id !== id))
  // }

  // const toggleVisiblity = (id) => {
  //   setPosts((prevState) =>
  //       prevState.map((o) => {
  //         if (o.id === id) {
  //           const hidden = !o.hidden;
  //           return { ...o, hidden };
  //         }
  //         return o;
  //       })
  //   );
  // }

  // const edit = (id) => { 
  //   const post = posts.find(post => post.id === id) 
  //   if (post === undefined) {            
  //     return;
  //   }         
  //   setEdited(post)  
  // }

  // const save = (post) => { 
  //   if (edited.id === 0) {
  //     setPosts((prevState) =>[{...post}, ...prevState]);
  //     setEdited(empty);          
  //       return           
  //   }
  
  //   setPosts((prevState) => prevState.map((o) => {
  //     if (o.id !== post.id){
  //       return o;
  //     } 

  //     return {...post} 
  //   }));           
  //   setEdited(empty) 
  //   return;
  // }

  // const submit = () => {
  //   if (edited.id === 0){
  //     edited.id =  edited.id ||Date.now();
  //     edited.created = edited.created || Date.now

  //     const parsed = edited.tags?.map(o => o.replace('#', '')).filter(o => o.trim() !== '') || [];
  //     const tags = parsed.length !== 0 ? parsed : null;
  //     edited.tags = tags;
  //     edited.photo = edited.photo?.url ? {alt: '', ...edited.photo}: null
  //   }

  //   setPosts((prevState) => [...prevState, edited])
  //   setEdited(empty)
  // }

  // const change = ({name, value}) => {
  //   if (name === 'tags') {
  //     const parsed = value.split(' ');
  //     setEdited((prevState) => ({...prevState, [name]: parsed }));
  //     return;
  //   }
  //   if (name === 'photo') {
  //      setEdited((prevState) => ({...prevState, photo: {url: value, alt: prevState.photo?.alt || ''}}));
  //       return;
  //   }
  //   if (name === 'alt') {
  //     setEdited((prevState) => ({...prevState, photo: {url: prevState.photo?.url || '', alt: value}}));
  //       return;
  //   }
  
  //   setEdited((prevState) => ({ ...prevState, [name]: value }));
  // }

  // const cancel = () => {
  //   setEdited(empty)
  // }
  // const value = {
  //   posts,
  //   like,
  //   remove,
  //   toggleVisiblity,
  //   edit,
  //   save,
  //   edited,
  //   cancel,
  //   submit,
  //   change,
  // };
  
  const [state, dispatch] = useReducer(reducer, initialState);
  const value = useMemo (() => ({state, dispatch}), [state]);
  return (
    <PostsContext.Provider value={value}>
      {props.children}
    </PostsContext.Provider>
  )
}