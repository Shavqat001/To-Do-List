'use strict';

const rootEl = document.getElementById('root');

const btnSendReq = document.createElement('button');
btnSendReq.dataset.action = 'load';
btnSendReq.textContent = 'Загрузить данные';
rootEl.appendChild(btnSendReq);

const postsEl = document.createElement('div');
postsEl.dataset.id = 'wall';
rootEl.appendChild(postsEl);

const loaderEl = document.createElement('div');
loaderEl.dataset.id = 'loader';
loaderEl.textContent = 'Данные загружаются';

const divErrEl = document.createElement('div');
divErrEl.textContent = 'Произошла ошибка: ';

const spanErrEl = document.createElement('span');
spanErrEl.dataset.id = 'error';
divErrEl.appendChild(spanErrEl);

const btnErrEl = document.createElement('button');
btnErrEl.dataset.action = 'retry';
btnErrEl.textContent = 'Повторить запрос';
divErrEl.appendChild(btnErrEl);

const posts = [];
const apiUrl = 'http://127.0.0.1:9999/api/hw30/posts';

function loadData(callbacks) {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }

    const xhr = new XMLHttpRequest();
    xhr.open('GET', apiUrl);
    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);

            btnSendReq.style.display = 'none';
            postsEl.style.display = 'none';

            spanErrEl.textContent = error.message;
            rootEl.appendChild(divErrEl);
            divErrEl.style.display = 'block';

            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }

        const data = JSON.parse((xhr.responseText));
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess(data);
        }
    };

    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({error: 'network error'});
        }
    };

    xhr.onloadend = () => {
        if (typeof callbacks.onFinish === 'function') {
            callbacks.onFinish();
        }
    };

    xhr.send(); 
}

function makePostEl(post) {
    if (post.type === 'text') {
        const divEl = document.createElement('div');

        divEl.dataset.id = post.id;
        divEl.dataset.type = post.type;

        const textEl = document.createElement('div');
        textEl.textContent = post.content;
        divEl.appendChild(textEl);
        return divEl;
    }

    if (post.type === 'image') {
        const divEl = document.createElement('div');

        divEl.dataset.id = post.id;
        divEl.dataset.type = post.type;

        const imgEl = document.createElement('img');
        imgEl.src = post.content;
        divEl.appendChild(imgEl);
        return divEl;
    }

    if (post.type === 'video') {
        const divEl = document.createElement('div');

        divEl.dataset.id = post.id;
        divEl.dataset.type = post.type;

        const videoEl = document.createElement('video');
        videoEl.src = post.content;
        videoEl.setAttribute('controls', 'true');
        divEl.appendChild(videoEl);
        return divEl;
    }
}

function renderPosts(el, postArr) {
    postArr.map(makePostEl).forEach(item => {
        item === postArr.type;
        el.appendChild(item);
    });
}

btnSendReq.addEventListener('click', () => {

    loadData({
        onStart: () => {
            rootEl.appendChild(loaderEl);
            // posts = [];
        },
        onFinish: () => rootEl.removeChild(loaderEl),
        onSuccess: (data) => {
            // console.log(data)
            // posts = [...data];
            posts.push(...data);
            renderPosts(postsEl, posts);
            postsEl.style.display = 'block';
        },
        onError: error => console.log(error),
    });
});

btnErrEl.addEventListener('click', () => {

    loadData({
        onStart: () => {
            rootEl.appendChild(loaderEl);
            rootEl.removeChild(divErrEl);
        },
        onFinish: () => {
            rootEl.removeChild(loaderEl);
            postsEl.style.display = 'block';
            btnSendReq.style.display = 'block';
        },
        onSuccess: (data) => {
            postsEl.style.display = 'none';
            posts.push(...data);
            renderPosts(postsEl, posts);
        },
        onError: error => console.log(error),
    });
});


