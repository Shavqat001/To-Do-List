import React from 'react'

function Tags({tags}) {
  return (
    <> 
     теги: { tags.map(tag => ( <button>#{tag}</button>))}  
    </>
  )
}

export default Tags