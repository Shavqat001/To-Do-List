UPDATE banners
SET title = 'Машина мечты ждёт вас'
WHERE id = 4;