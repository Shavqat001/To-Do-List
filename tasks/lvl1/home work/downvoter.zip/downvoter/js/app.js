'use strict';


const rootEl = document.querySelector('#root');

const formEl = document.createElement('form');
formEl.dataset.id = 'comment-form';
rootEl.appendChild(formEl);

const textareaEl = document.createElement('textarea');
textareaEl.dataset.input = 'text';
formEl.appendChild(textareaEl);

const btnEl = document.createElement('button');
btnEl.dataset.action = 'add';
btnEl.textContent = 'Добавить';
formEl.appendChild(btnEl);

const ulEl = document.createElement('ul');
ulEl.dataset.id = 'comments-list';
rootEl.appendChild(ulEl);

const errorEl = document.createElement('div');
errorEl.dataset.id = 'message';
rootEl.appendChild(errorEl);

let nextId = 1;
const likes = 0;
const minLikes = -10;

let comments = [];

formEl.onsubmit = e => {
    e.preventDefault();

    errorEl.textContent = '';
    let error = null;
    const text = textareaEl.value.trim();
    if (text === '') {
        error = 'Заполните поле название';
        errorEl.textContent = error;
        textareaEl.focus();
        return;
    }

    const obj = {
        id: nextId++,
        text,
        likes,
    };

    comments.push(obj);

    const liEl = document.createElement('li');
    liEl.setAttribute('data-comment-id', obj.id);
    ulEl.appendChild(liEl);

    const commentEl = document.createElement('span');
    commentEl.dataset.info = 'text';
    commentEl.textContent = obj.text;
    liEl.appendChild(commentEl);

    const likeEl = document.createElement('span');
    likeEl.dataset.info = 'likes';
    likeEl.textContent = obj.likes;
    liEl.appendChild(likeEl);

    // liEl.textContent += ' ❤';
    const heartEl = document.createElement('span');
    heartEl.textContent = ' ❤';
    liEl.insertBefore(heartEl, likeEl);

    const likeBtnEl = document.createElement('button');
    likeBtnEl.dataset.action = 'like';
    likeBtnEl.textContent = '+';
    liEl.appendChild(likeBtnEl);

    const dislikeBtnEl = document.createElement('button');
    dislikeBtnEl.dataset.action = 'dislike';
    dislikeBtnEl.textContent = '-';
    liEl.appendChild(dislikeBtnEl);

    likeBtnEl.onclick = () => {
        obj.likes++;
        likeEl.textContent = obj.likes;
    };

    dislikeBtnEl.onclick = () => {
        obj.likes--;
        likeEl.textContent = obj.likes;
        if (obj.likes === minLikes) {
            comments = comments.filter(el => el !== obj);
            ulEl.removeChild(liEl);
        }
    };

    textareaEl.focus();
    formEl.reset();
};