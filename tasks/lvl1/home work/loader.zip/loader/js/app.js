'use strict';

const time = 5000;
const el = document.querySelector('[data-id="loader"]');

setTimeout(() => {
    el.style.display = 'none';
}, time);