'use strict';

const methods = new Map();
methods.set('/posts.getById', function ({ res, searchParams }) {
    try {
        sendJSON(res, getPost(getId(searchParams)));
    } catch (getByIdError) {
        handleError(res, getByIdError);
    }
});