const fs = require('node:fs');

const users = [
    '1,Vasya,+992000000001',
    '2,Petya,+992000000002',
    '3,Masha,+992000000003',
];

fs.writeFile('export.txt', users.join('\n'), (err) => {
    if (err) { 
        throw err;
    }
    console.log('The file has been saved!');
});