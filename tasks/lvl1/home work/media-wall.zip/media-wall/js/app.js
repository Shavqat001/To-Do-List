'use strict';
const postsUrl = 'http://127.0.0.1:9999/api/hw29/posts';
let posts = [];

const rootEl = document.getElementById('root');
const loaderEl = document.createElement('div');
const wallEl = document.createElement('div');
wallEl.dataset.id = 'wall';
loaderEl.dataset.id = 'loader';
loaderEl.textContent = 'Loading...';
rootEl.append(loaderEl, wallEl);

const loadData = (callbacks) => {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }
    const xhr = new XMLHttpRequest();
    xhr.open('GET', postsUrl);


    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);
            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }
        const data = JSON.parse(xhr.responseText);
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess(data);
        }
    };

    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({error: 'network error'});
        }
    };

    xhr.onloadend = () => {
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onFinish();
            makeWall(wallEl, posts);
            console.log(posts);
        }
    };
    xhr.send();

    console.log(xhr.response);
};


const makePostEl = (post) => {

    const imgEl = document.createElement('div');
    if (post.type === 'text') {
        imgEl.dataset.type = post.type;
        imgEl.dataset.id = post.id;
        const txtEl = document.createElement('div');
        txtEl.textContent = post.content;
        imgEl.append(txtEl);
        return imgEl;
    }

    if (post.type === 'image') {
        imgEl.dataset.type = post.type;
        imgEl.dataset.id = post.id;
        const imageEl = document.createElement('img');
        imageEl.src = post.content;
        imgEl.append(imageEl);
        return imgEl;
    }

    if (post.type === 'video') {
        imgEl.dataset.type = post.type;
        imgEl.dataset.id = post.id;
        const videoEl = document.createElement('video');
        videoEl.src = post.content;
        videoEl.setAttribute('controls', '');
        imgEl.append(videoEl);
        return imgEl;
    }
    return imgEl;
};

const makeWall = (el, items) => {
    items.map(makePostEl).forEach(e => el.append(e));
};

loadData({
    onStart: () => (loaderEl.style.display = 'block'),
    onSuccess: (data) => {
        posts = data;
    },
    onFinish: () => {
        loaderEl.remove();
    },
    onError: (error) => console.log(error),
});