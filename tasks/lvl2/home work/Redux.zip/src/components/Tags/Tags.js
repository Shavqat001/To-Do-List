import React from 'react'

function Tags({tags}) {
  return (
    <>
    {"теги: "} 
    {tags.map(el => (
        <button key={el}>#{el}</button>
    ))}
    </>
  )
}

export default Tags