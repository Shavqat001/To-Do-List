'use strict';

const { createServer } = require('node:http');
const { fileURLToPath } = require('node:url');
const path = require('node:path');
const fs = require('node:fs');
const error = 404;

const server = createServer((req, res) => {
    const { url } = req;
    if (url.endsWith('.png') || url.endsWith('.jpg')) {
        const currentUrl = new URL(import.meta.url);
        const filePath = path.join(path.dirname(fileURLToPath(currentUrl)), url);
        const contentType = url.endsWith('.png') ? 'image/png' : 'image/jpeg';
        fs.access(filePath, fs.constants.F_OK, (err) => {
            if (err) {
                res.writeHead(error);
                res.end();
            } else {
                res.setHeader('Content-Type', contentType);
                fs.createReadStream(filePath).pipe(res);
            }
        });
    } else {
        res.writeHead(error);
        res.end();
    }
});

const port = 9999;
server.listen(port);