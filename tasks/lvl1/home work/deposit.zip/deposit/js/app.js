const input = 1000;
const maxPercent = 6;
const minPercent = 4;

const maxYearly = (input * maxPercent) / 100;
const minYearly = (input * minPercent) / 100;
const maxMonthly = maxYearly / 12;
const minMonthly = minYearly / 12;

console.log(maxMonthly);
console.log(minMonthly);
console.log(maxYearly);
console.log(minYearly);