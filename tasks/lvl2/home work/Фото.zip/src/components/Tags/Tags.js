import React from 'react'

function Tags({ tags }) {

    return (
        <>
            теги: {tags.map((o, i) => <button key={i}>#{o}</button>)}
        </>
    )
}

export default Tags