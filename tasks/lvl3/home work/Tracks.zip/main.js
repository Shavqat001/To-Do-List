const fs = require('node:fs');

const content = fs.readFileSync('music.txt', 'utf-8');
const lines = content.split('\r\n');
lines.forEach(line => {
    const splitedLine = line.split('|');
    splitedLine.forEach(lineEl => {
        const valueOfLineElement = lineEl.slice(lineEl.indexOf(':') + 1, lineEl.length);
        console.log(valueOfLineElement);
    });
});

