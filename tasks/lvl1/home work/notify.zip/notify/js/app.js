function hasUnread(items) {
    return !items.every(post => post.read === true);
}

const posts = [
    {
        id: 1,
        read: true,
    },
    {
        id: 2,
        read: true,
    },
    {
        id: 3,
        read: false,
    },
]
const notify = hasUnread(posts);
console.log(notify);