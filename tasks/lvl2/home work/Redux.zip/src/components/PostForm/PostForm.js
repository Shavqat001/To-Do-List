import React, { useRef } from 'react'
import { editCancel, editChange, editSubmit } from '../../store/actions';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';

export default function PostForm() {
    const dispatch = useDispatch();
    const edited = useSelector((state) => state.edited, shallowEqual);
    const firstFocusEl = useRef(null);

    const handleSubmit = (ev) => {
        ev.preventDefault();
        dispatch(editSubmit());
        //submit();
        firstFocusEl.current.focus();
    };

    const handleReset = (ev) => {
        ev.preventDefault();
        dispatch(editCancel());
        //cancel();
    };

    const handleChange = (ev) => {
        const { name, value } = ev.target;
        dispatch(editChange(name, value));
        //change({name, value})
    };

    return (
        <form onSubmit={handleSubmit}>
            <textarea
                ref={firstFocusEl}
                name='content'
                placeholder='content'
                value={edited.content || ''}
                onChange={handleChange} />
            <input
                name='tags'
                placeholder='tags'
                value={edited.tags?.join(' ') || ''}
                onChange={handleChange}
            />
            <input
                name='photo'
                placeholder='photo'
                value={edited.photo?.url || ''}
                onChange={handleChange}
            />
            <input
                name='alt'
                placeholder='alt'
                value={edited.photo?.alt || ''}
                onChange={handleChange}
            />
            {!edited.empty && <button onClick={handleReset}>Отменить</button>}
            <button>Ok</button>
        </form>
    )
}
