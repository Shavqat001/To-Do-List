import { createContext } from 'react';

const PostsContext = createContext();

export default PostsContext;