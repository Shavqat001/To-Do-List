import React, { useContext, useRef } from 'react';
import { editChange, editCancel, editSubmit } from '../../store/actions';
import PostsContext from '../../contexts/PostsContext';
// import { shallowEqual, useDispatch, useSelector } from 'react-redux';


export default function PostForm() {
  // const dispatch = useDispatch();
  // const edited = useSelector((state) => state.edited, shallowEqual);
  const {state: {edited}, dispatch} = useContext(PostsContext)
  const firstFocusEl = useRef(null);

  const handleSubmit = (evt) => {
    evt.preventDefault();
    dispatch(editSubmit());
    firstFocusEl.current.focus();
  };

  const handleChange = (evt) => {
    const {name, value} = evt.target;
    dispatch(editChange(name, value));
    //dispatch({type: 'POST_EDIT_CHANGE', payload: {name, value}})
  };

  const handleCancel = (evt) => {
    evt.preventDefault()
    dispatch(editCancel())
    //dispatch({type: 'POST_EDIT_CANCEL'})
  };


  return (
    <form onSubmit={handleSubmit}>
        <textarea 
          ref={firstFocusEl} 
          name="content" 
          value={edited.content || ''} 
          onChange={handleChange}/><br></br>
        <input 
          name="tags" 
          placeholder='tags' 
          value={edited.tags?.join(' ') || ''} 
          onChange={handleChange}/><br></br>
        <input 
          name="photo" 
          placeholder="photo"
          value={edited.photo?.url || ''}
          onChange={handleChange}
          /><br></br>
        <input 
          name="alt"
          placeholder="alt"
          value={edited.photo?.alt || ''} 
          onChange={handleChange}
          /><br></br>
        <button type='submit'>Ok</button>
        {edited.id !== 0 ? (
          <button type="button" onClick={handleCancel} className="btn btn-secondary px-5">
            Отменить
          </button>
        ) : null}
    </form>
  )
}
