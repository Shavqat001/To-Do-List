'use strict';

const post = {
    id: 0,
    userLiked: false,
};
const liker = document.querySelector('[data-action="like"]');
const logo = document.querySelector('.logo');

liker.onclick = () => {
    if (post.id === 0 && post.userLiked !== true) {
        logo.src = 'img/liked.svg';
        post.userLiked = true;
    } else {
        logo.src = 'img/unliked.svg';
        post.userLiked = false;
    }
};