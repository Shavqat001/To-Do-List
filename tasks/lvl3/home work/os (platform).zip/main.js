const fs = require('node:os');
const platform = fs.platform();
console.log(platform);