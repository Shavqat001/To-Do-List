import React, { useState } from 'react'
import Post from '../Post/Post'
import PostForm from '../PostForm/PostForm';

function Wall(props) {
    const [posts, setPosts] = useState([
        {
            id: 2,
            author: {
                id: 1,
                avatar: 'https://alif-skills.pro/media/logo_alif.svg',
                name: 'Alif Skills',
            },
            content: 'Ну как, вы справились с домашкой?',
            photo: null,
            hit: true,
            likes: 222,
            likedByMe: true,
            hidden: true,
            tags: ['deadline', 'homework'],
            created: 1603774800,
        },
        {
            id: 1,
            author: {
                id: 1,
                avatar: 'https://alif-skills.pro/media/logo_alif.svg',
                name: 'Alif Skills',
            },
            content: null,
            photo: {
                url: "https://alif-skills.pro/media/meme.jpg",
                alt: 'Мем про дедлайн',
            },
            hit: true,
            likes: 10,
            likedByMe: true,
            hidden: false,
            created: 1603501200,
        },
    ]);
    const [edited, setEdited] = useState();

    const handlePostLike = (id) => {
        setPosts((prevState) => prevState.map(o => {
            if (o.id !== id) {
                return o;
            }

            const likedByMe = !o.likedByMe;
            const likes = likedByMe ? o.likes + 1 : o.likedByMe - 1;
            return { ...o, likedByMe, likes };
        }));
    };

    const handlePostRemove = (id) => {
        setPosts((prevState) => prevState.filter(o => o.id !== id));
    }

    const handlePostVisibility = (id) => {
        const visibility = [...posts].filter((post) => {
            if (post.id === id) {
                post.hidden = !post.hidden
            }
            return post
        })
        setPosts(visibility)
    }

    const handlePostEdit = (id) => {
        const post = posts.find(o => o.id === id);
        if (post === undefined) {
            return;
        }
        setEdited(post);
        console.log(post)
    };

    const handlePostSave = (post) => {
        if (edited !== undefined) {
            setPosts((prevState) => prevState.map((o) => {
                if (o.id !== post.id) {
                    return o;
                }

                return { ...post };
            }))
            setEdited(undefined);
            return;
        }
        setPosts((prevState) => [{...post }, ...prevState])
        setEdited(undefined);
    };

    return (
        <>
            <PostForm edited={edited} onSave={handlePostSave} />
            <div>
                {posts.map(o => <Post
                    key={o.id}
                    post={o}
                    onLike={handlePostLike}
                    onDelete={handlePostRemove}
                    onHide={handlePostVisibility}
                    onShow={handlePostVisibility}  
                    onEdit={handlePostEdit}    
                    />)
                }
            </div>
        </>
    );
}

export default Wall