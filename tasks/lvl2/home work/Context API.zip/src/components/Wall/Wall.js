import React from 'react'
import Post from '../Post/Post';
import PostForm from '../PostForm/PostForm';
// import { shallowEqual, useSelector } from 'react-redux';
import { useContext } from 'react';
import PostsContext from '../../contexts/PostsContext';

function Wall() {

    // const posts = useSelector((state) => state.posts, shallowEqual);
    const {state: {posts}} = useContext(PostsContext);

    return (
      <>
      <PostForm  />
      <div>
        {posts.map(post =>  <Post key={post.id} post={post} />)}
      </div>
      </>
    );
}

export default Wall