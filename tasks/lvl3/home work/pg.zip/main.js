'use strict';
import http from 'node:http';
import pg from 'pg';
const { Pool } = pg;

const dsn = process.env.DSN ?? 'postgres://app:pass@localhost:5432/db';
const pool = new Pool({ connectionString: dsn });

pg.types.setTypeParser(20, Number);
pg.types.setTypeParser(1016, o => pg.types.getTypeParser(1016)(o).map(Number));


const statusNotFound = 404;
const statusBadRequest = 400;
const statusOkRequest = 200;


const methods = new Map();

methods.set('/posts.get', async ({ response }) => {
    const { rows } = await pool.query(
        `
        SELECT * FROM posts
        WHERE removed = FALSE
        ORDER BY id DESC
        `
    );
    const posts = rows;
    response.writeHead(statusOkRequest, { 'Content-type': 'application/json' });
    response.end(JSON.stringify(posts));
});

methods.set('/posts.getById', async ({ searchParams, response }) => {
    const id = Number(searchParams.get('id'));
    if (!searchParams.has('id') | Number.isNaN(id)) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }
    const { rows: [row] } = await pool.query(
        `
        SELECT * FROM posts
        WHERE id = $1 AND removed = FALSE
        `,
        [id]
    );
    const post = row;
    if (post === undefined) {
        response.writeHead(statusNotFound);
        response.end();
        return;
    }
    response.writeHead(statusOkRequest, { 'Content-type': 'application/json' });
    response.end(JSON.stringify(post));
});


methods.set('/posts.post', async ({ response, searchParams }) => {
    if (!searchParams.has('content')) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }

    const { rows: [row] } = await pool.query(
        `
        INSERT INTO posts(content)
        VALUES ($1)
        RETURNING id, content, created
        `,
        [searchParams.get('content')]
    );

    response.writeHead(statusOkRequest, { 'Content-type': 'application/json' });
    response.end(JSON.stringify(row));
});

methods.set('/posts.edit', async ({ searchParams, response }) => {
    const id = Number(searchParams.get('id'));
    if (!searchParams.has('id') | Number.isNaN(id)) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }
    if (!searchParams.has('content')) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }

    const { rows: [row] } = await pool.query(
        `
        SELECT * FROM posts
        WHERE id = $1 AND removed = FALSE
        `,
        [id]
    );
    const post = row;
    if (post === undefined) {
        response.writeHead(statusNotFound);
        response.end();
        return;
    }

    const content = searchParams.get('content');
    const { rows: [updatedPost] } = await pool.query(
        `
        UPDATE posts SET content = $1
        WHERE id = $2
        `,
        [content, id]
    );

    post.content = content;

    response.writeHead(statusOkRequest, { 'Content-type': 'application/json' });
    response.end(JSON.stringify(post));
});

methods.set('/posts.delete', async ({ searchParams, response }) => {
    const id = Number(searchParams.get('id'));
    if (!searchParams.has('id') | Number.isNaN(id)) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }

    const { rows: [row] } = await pool.query(
        `
        SELECT * FROM posts
        WHERE id = $1 AND removed = FALSE
        `,
        [id]
    );
    const post = row;
    if (post === undefined) {
        response.writeHead(statusNotFound);
        response.end();
        return;
    }
    post.removed = true;
    
    const { rows: [updatedPost] } = await pool.query(
        `
        UPDATE posts SET removed = TRUE
        WHERE id = $1
        `,
        [id]
    );

    response.writeHead(statusOkRequest, { 'Content-type': 'application/json' });
    response.end(JSON.stringify(post));
});

methods.set('/posts.restore', async ({ searchParams, response }) => {
    const id = Number(searchParams.get('id'));
    if (!searchParams.has('id') | Number.isNaN(id)) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }  
    const { rows: [row] } = await pool.query(
        `
        SELECT * FROM posts
        WHERE id = $1
        `,
        [id]
    );
    const post = row;
    if (post === undefined) {
        response.writeHead(statusNotFound);
        response.end();
        return;
    }
    if (!post.removed) {
        response.writeHead(statusBadRequest);
        response.end();
        return;
    }
    const { rows: [updatedPost] } = await pool.query(
        `
        UPDATE posts SET removed = FALSE
        WHERE id = $1
        `,
        [id]
    );
    post.removed = false;
    response.writeHead(statusOkRequest, { 'Content-type': 'application/json' });
    response.end(JSON.stringify(post));
});

const server = http.createServer(async (request, response) => {
    try {
        const { searchParams, pathname } = new URL(request.url, `http://${request.headers.host}`);
        const method = methods.get(pathname);
        const params = {
            request,
            response,
            searchParams,
            pathname,
        };
        if (method === undefined) {
            response.writeHead(statusNotFound);
            response.end();
            return;
        }
        await method(params);
    } catch (e) {
        console.log(e.message);
    }

});

const port = 9999;
server.listen(port);

function shutdown() {
    server.close(() => {
        console.log('server closed');
        pool.end(() => console.log('pool closed'));
    });
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);